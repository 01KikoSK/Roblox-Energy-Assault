-- Get a reference to the player's rank object
local rank = game.Players.LocalPlayer.Data.Rank

-- Create a loop that runs continuously
while true do
    -- Wait for 10 seconds
    wait(10)
    
    -- Increment the player's rank by 1
    rank.Value = rank.Value + 1
    
    -- Save the updated rank back to the game
    rank:Write()
end