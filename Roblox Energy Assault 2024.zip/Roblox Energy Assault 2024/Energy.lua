-- Create the GUI
local energyAssaultGUI = Instance.new(&quot;ScreenGui&quot;)
energyAssaultGUI.Name = &quot;EnergyAssaultGUI&quot;
energyAssaultGUI.Parent = game.Players.LocalPlayer:WaitForChild(&quot;PlayerGui&quot;)

-- Create the Frame
local energyAssaultFrame = Instance.new(&quot;Frame&quot;)
energyAssaultFrame.Name = &quot;EnergyAssaultFrame&quot;
energyAssaultFrame.Parent = energyAssaultGUI
energyAssaultFrame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
energyAssaultFrame.Position = UDim2.new(0.5, -100, 0.5, -100)
energyAssaultFrame.Size = UDim2.new(0, 200, 0, 200)

-- Create the Slider
local energySlider = Instance.new(&quot;TextButton&quot;)
energySlider.Name = &quot;EnergySlider&quot;
energySlider.Parent = energyAssaultFrame
energySlider.BackgroundColor3 = Color3.fromRGB(0, 128, 128)
energySlider.Size = UDim2.new(1, 0, 0.1, 0)
energySlider.Text = &quot;Energy: 22500&quot;

-- Function to update the energy level
local function updateEnergy(slider, newEnergy)
    slider.Text = &quot;Energy: &quot; .. newEnergy
end

-- Function to change the energy level
local function changeEnergy(slider, delta)
    local currentEnergy = tonumber(string.sub(slider.Text, 9, -1))
    local newEnergy = math.clamp(currentEnergy + delta, 0, 100)
    slider.Size = UDim2.new(1, 0, 0.1, 0)
    updateEnergy(slider, newEnergy)
end

-- Connect the slider to the changeE